#include <bits/stdc++.h>
using namespace std;
int main() {
    // subtract two numbers
    int a,b;
    cin>>a>>b;
    cout<<a-b<<endl;
    cout<<a<<" "<<b<<endl;
}
