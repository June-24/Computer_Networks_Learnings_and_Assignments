#include <bits/stdc++.h>
using namespace std;
int main() {
    // add 2 numbers
    int a,b;
    cin>>a>>b;
    cout<<a+b+1<<endl;
    cout<<a<<" "<<b<<endl;

}
