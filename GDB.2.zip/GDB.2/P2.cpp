#include <bits/stdc++.h>
using namespace std;
int main() {
    //multiply two number
    int a,b;
    cin>>a>>b;
    cout<<a*b<<endl;
    cout<<a<<" "<<b<<endl;
}
