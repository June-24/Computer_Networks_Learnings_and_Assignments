#include<iostream>
using namespace std;
int main(){
    // just run this first
    system("g++ C1.cpp -o C1");
    system("g++ C2.cpp -o C2");
    system("g++ C3.cpp -o C3");
    system("g++ C4.cpp -o C4");
    system("g++ S1.cpp -o S1");
    system("g++ S2.cpp -o S2");
    system("g++ S3.cpp -o S3");
    system("g++ S4.cpp -o S4");
    system("g++ S.cpp -o S");
}